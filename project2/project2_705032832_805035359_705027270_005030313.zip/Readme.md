Readme
------
ECE 232E project 2
------

Team Member

Yunhao Ba (705032832)
Shuangyu Li (805035359)
Jingchi Ma (705027270)
Chenguang Yuan (005030313)
------
All the R code are included in jupyter notebook. 
Run in order to get corresponding result.
part1: facebook network
part2: Google+ network

------
package:
igraph
Readme.md
-----
