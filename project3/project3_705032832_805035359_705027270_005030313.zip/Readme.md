Readme
------
ECE 232E project 2
------

Team Member

Yunhao Ba (705032832)
Shuangyu Li (805035359)
Jingchi Ma (705027270)
Chenguang Yuan (005030313)
------
All the Python code are included in jupyter notebook. 
Run in order to get corresponding result.

1. Project3_final_version : main part from q1-q24
2. Project3_normalized: solution 1 to q25
3. Project3_limited_actions: solution 2 to q25
------
package:
Numpy
matplotlib
pandas
cvx
-----
